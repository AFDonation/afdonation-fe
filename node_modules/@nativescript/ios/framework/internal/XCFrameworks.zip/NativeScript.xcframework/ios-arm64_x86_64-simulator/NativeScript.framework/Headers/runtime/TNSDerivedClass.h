#ifndef TNSDerivedClass_h
#define TNSDerivedClass_h

@protocol TNSDerivedClass

@end

#endif /* TNSDerivedClass_h */
